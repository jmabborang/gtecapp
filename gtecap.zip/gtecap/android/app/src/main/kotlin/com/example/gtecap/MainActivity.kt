package com.example.gtecap

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
